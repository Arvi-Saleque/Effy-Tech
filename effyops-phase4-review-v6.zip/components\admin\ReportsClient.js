"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { formatMinutes } from "@/lib/admin/time";
import WorkHoursChart from "./WorkHoursChart";
import { 
  Calendar, 
  FileSpreadsheet, 
  Clock, 
  TrendingUp, 
  CheckCircle,
  AlertTriangle,
  ChevronRight
} from "lucide-react";

export default function ReportsClient({ initialData, currentRange }) {
  const router = useRouter();
  const { summary, history, assignments = [], workBlocksHistory = [], startDate, endDate } = initialData;

  const handleRangeChange = (range) => {
    router.push(`/admin/reports?range=${range}`);
    router.refresh();
  };

  // Format chart data: [{ name, hours }]
  const chartData = summary.map(item => ({
    name: item.name,
    hours: item.totalHours
  }));

  return (
    <div className="space-y-8 font-sans animate-fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs text-neutral-400 font-semibold uppercase tracking-widest block mb-1">
            Reports
          </span>
          <h2 className="text-2xl font-extrabold text-neutral-100 tracking-tight">
            Work Analytics & Logs
          </h2>
        </div>

        {/* Range Selector */}
        <div className="inline-flex p-1 bg-neutral-950/60 border border-neutral-800/80 rounded-xl">
          {["today", "week", "month"].map((r) => (
            <button
              key={r}
              onClick={() => handleRangeChange(r)}
              className={`px-4 py-2 text-xs font-semibold rounded-lg capitalize transition-all duration-200 ${
                currentRange === r 
                  ? "bg-emerald-400 text-emerald-950 shadow-lg font-bold" 
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              {r === "week" ? "This Week" : r === "month" ? "This Month" : "Today"}
            </button>
          ))}
        </div>
      </div>

      <div className="text-xs text-neutral-400 pl-1 font-mono">
        Period: <span className="text-neutral-200">{startDate}</span> to <span className="text-neutral-200">{endDate}</span>
      </div>

      {/* Analytics Summary and Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Aggregated Summary Table */}
        <div className="lg:col-span-2 bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-6 shadow-xl backdrop-blur-xl flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-neutral-100 mb-4 flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-emerald-400" />
              Member Aggregate Summary
            </h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-neutral-800/80 text-neutral-400 text-xs uppercase tracking-wider">
                    <th className="pb-3 font-semibold">Member</th>
                    <th className="pb-3 font-semibold">Total Hours</th>
                    <th className="pb-3 font-semibold">Days Worked</th>
                    <th className="pb-3 font-semibold">Avg Hours/Day</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/40">
                  {summary.map(item => (
                    <tr key={item.id} className="text-neutral-300">
                      <td className="py-4 font-semibold text-neutral-100">{item.name}</td>
                      <td className="py-4 font-mono text-xs text-neutral-200 font-semibold">{item.totalHours}h</td>
                      <td className="py-4 font-mono text-xs">{item.daysWorked}d</td>
                      <td className="py-4 font-mono text-xs text-neutral-400">{item.averageHours}h/d</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Aggregate worked hours chart */}
        <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-6 shadow-xl backdrop-blur-xl flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-neutral-100 mb-4 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-400" />
              Work Distribution (Hours)
            </h3>
            <WorkHoursChart data={chartData} />
          </div>
        </div>

      </div>

      {/* Assigned Work in Selected Period Section */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-emerald-400" />
          Task History in Selected Period ({assignments.length})
        </h3>

        {assignments.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-neutral-800/60 rounded-2xl bg-neutral-900/10 text-xs text-neutral-500 font-medium">
            No work assignments found for the selected period.
          </div>
        ) : (
          <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-6 shadow-xl backdrop-blur-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-neutral-800/80 text-neutral-400 text-xs uppercase tracking-wider">
                    <th className="pb-3 font-semibold">Date</th>
                    <th className="pb-3 font-semibold">Assigned To</th>
                    <th className="pb-3 font-semibold">Title</th>
                    <th className="pb-3 font-semibold">Status</th>
                    <th className="pb-3 font-semibold">Assigned By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/40">
                  {assignments.map(task => (
                    <tr key={task.id} className="text-neutral-300">
                      <td className="py-3.5 font-mono text-xs text-neutral-400">
                        {task.work_date}
                      </td>
                      <td className="py-3.5 font-semibold text-neutral-100">
                        {task.assignedToName}
                      </td>
                      <td className="py-3.5">
                        <span className="font-medium text-neutral-200 block">
                          {task.title}
                        </span>
                        {task.description && (
                          <span className="text-xs text-neutral-500 block max-w-md truncate">
                            {task.description}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 text-xs">
                        <span className={`px-2 py-0.5 rounded font-semibold uppercase tracking-wider text-[9px] border ${
                          task.status === "done" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" :
                          task.status === "in_progress" ? "bg-blue-500/10 border-blue-500/20 text-blue-400" :
                          task.status === "cancelled" ? "bg-neutral-800 border-neutral-700 text-neutral-500" :
                          "bg-amber-500/10 border-amber-500/20 text-amber-400"
                        }`}>
                          {task.status === "pending" ? "To Do" :
                           task.status === "in_progress" ? "In Progress" :
                           task.status === "done" ? "Done" :
                           task.status}
                        </span>
                      </td>
                      <td className="py-3.5 text-xs text-neutral-400">
                        {task.assignedByName}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Work Blocks in Selected Period Section */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
          <Clock className="h-5 w-5 text-emerald-400" />
          Work Blocks in Selected Period ({workBlocksHistory.length})
        </h3>

        {workBlocksHistory.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-neutral-800/60 rounded-2xl bg-neutral-900/10 text-xs text-neutral-500 font-medium">
            No work blocks recorded in this period.
          </div>
        ) : (
          <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-6 shadow-xl backdrop-blur-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-neutral-800/80 text-neutral-400 text-xs uppercase tracking-wider">
                    <th className="pb-3 font-semibold">Date</th>
                    <th className="pb-3 font-semibold">Member</th>
                    <th className="pb-3 font-semibold">Work Title</th>
                    <th className="pb-3 font-semibold">Time</th>
                    <th className="pb-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/40 text-xs">
                  {workBlocksHistory.map(block => {
                    const formatBlockDuration = (minutes) => {
                      if (!minutes || minutes <= 0) return "0m";
                      const hrs = Math.floor(minutes / 60);
                      const mins = minutes % 60;
                      if (hrs > 0) return `${hrs}h ${mins}m`;
                      return `${mins}m`;
                    };

                    return (
                      <tr key={block.id} className="text-neutral-300">
                        <td className="py-3.5 font-mono text-neutral-450">
                          {block.work_date}
                        </td>
                        <td className="py-3.5 font-semibold text-neutral-100">
                          {block.memberName}
                        </td>
                        <td className="py-3.5">
                          <span className="font-medium text-neutral-250 block">
                            {block.title}
                          </span>
                          {block.note && (
                            <span className="text-neutral-500 italic block mt-0.5 max-w-lg truncate">
                              &ldquo;{block.note}&rdquo;
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 font-mono text-neutral-350">
                          {block.status === "active" ? (
                            <span className="text-emerald-450 font-semibold">Active</span>
                          ) : (
                            formatBlockDuration(block.total_minutes)
                          )}
                        </td>
                        <td className="py-3.5">
                          <span className={`px-2 py-0.5 rounded font-semibold uppercase tracking-wider text-[9px] border ${
                            block.status === "done" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" :
                            block.status === "active" ? "bg-blue-500/10 border-blue-500/20 text-blue-400 animate-pulse" :
                            "bg-red-500/10 border-red-500/20 text-red-400"
                          }`}>
                            {block.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* History Log Section */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
          <Calendar className="h-5 w-5 text-emerald-400" />
          Workday Session History ({history.length})
        </h3>

        {history.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-neutral-800/60 rounded-2xl bg-neutral-900/10">
            <span className="text-xs text-neutral-500 font-medium">
              No historical workday sessions found for the selected period.
            </span>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((log) => {
              return (
                <div key={log.id} className="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl p-6 shadow-xl backdrop-blur-xl space-y-4">
                  
                  {/* Top info row */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800/60 pb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-neutral-100">{log.name}</span>
                      <ChevronRight className="h-4 w-4 text-neutral-600 hidden sm:block" />
                      <span className="text-xs font-semibold text-emerald-400 font-mono">
                        {log.work_date}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs">
                      <span className="text-neutral-500 font-mono">
                        Hours Worked: <strong className="text-neutral-200">{(log.total_minutes / 60).toFixed(1)}h</strong> ({formatMinutes(log.total_minutes)})
                      </span>
                      <span className={`text-[9px] font-bold tracking-wide uppercase px-2 py-0.5 rounded border ${
                        log.status === "ended" 
                          ? "bg-neutral-800 border-neutral-700 text-neutral-500" 
                          : log.status === "break"
                            ? "bg-amber-500/10 border-amber-500/20 text-amber-400"
                            : "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                      }`}>
                        {log.status === "ended" ? "Ended" : log.status === "break" ? "On Break" : "Active"}
                      </span>
                    </div>
                  </div>

                  {/* Body description */}
                  {log.current_work_title && (
                    <div className="text-xs text-neutral-300">
                      <span className="block text-[10px] text-neutral-500 font-bold uppercase tracking-wider mb-1">
                        Last Active Task
                      </span>
                      <p className="text-neutral-200 font-medium">
                        {log.current_work_title}
                      </p>
                    </div>
                  )}

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
