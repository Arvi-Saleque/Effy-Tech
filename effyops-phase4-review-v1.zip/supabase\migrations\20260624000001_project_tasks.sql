-- 1. Create tables
CREATE TABLE public.project_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES public.projects(id),
    title TEXT NOT NULL CHECK (trim(title) <> ''),
    description TEXT,
    status TEXT NOT NULL DEFAULT 'backlog' CHECK (status IN ('backlog', 'todo', 'in_progress', 'blocked', 'review', 'done', 'cancelled', 'archived')),
    priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    start_date DATE,
    due_date DATE,
    estimated_minutes INTEGER CHECK (estimated_minutes IS NULL OR estimated_minutes >= 0),
    progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent >= 0 AND progress_percent <= 100),
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_by UUID NOT NULL REFERENCES public.admin_profiles(id),
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT valid_dates CHECK (start_date IS NULL OR due_date IS NULL OR due_date >= start_date)
);

CREATE TABLE public.project_subtasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID NOT NULL REFERENCES public.project_tasks(id),
    title TEXT NOT NULL CHECK (trim(title) <> ''),
    description TEXT,
    status TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo', 'in_progress', 'blocked', 'review', 'done', 'cancelled', 'archived')),
    priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    due_date DATE,
    estimated_minutes INTEGER CHECK (estimated_minutes IS NULL OR estimated_minutes >= 0),
    progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent >= 0 AND progress_percent <= 100),
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_by UUID NOT NULL REFERENCES public.admin_profiles(id),
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.task_assignees (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID NOT NULL REFERENCES public.project_tasks(id),
    user_id UUID NOT NULL REFERENCES public.admin_profiles(id),
    assigned_by UUID NOT NULL REFERENCES public.admin_profiles(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT task_assignees_task_id_user_id_key UNIQUE (task_id, user_id)
);

CREATE TABLE public.subtask_assignees (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subtask_id UUID NOT NULL REFERENCES public.project_subtasks(id),
    user_id UUID NOT NULL REFERENCES public.admin_profiles(id),
    assigned_by UUID NOT NULL REFERENCES public.admin_profiles(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT subtask_assignees_subtask_id_user_id_key UNIQUE (subtask_id, user_id)
);

-- 2. updated_at triggers
CREATE TRIGGER set_project_tasks_updated_at
    BEFORE UPDATE ON public.project_tasks
    FOR EACH ROW
    EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER set_project_subtasks_updated_at
    BEFORE UPDATE ON public.project_subtasks
    FOR EACH ROW
    EXECUTE FUNCTION public.set_updated_at();

-- 3. Progress Recalculation Functions
CREATE OR REPLACE FUNCTION public.recalculate_task_progress_v1(p_task_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_total_subtasks INT;
    v_avg_progress INT;
BEGIN
    SELECT COUNT(*), COALESCE(ROUND(AVG(progress_percent)), 0)
    INTO v_total_subtasks, v_avg_progress
    FROM public.project_subtasks
    WHERE task_id = p_task_id AND status NOT IN ('cancelled', 'archived');

    IF v_total_subtasks > 0 THEN
        UPDATE public.project_tasks
        SET progress_percent = v_avg_progress
        WHERE id = p_task_id;
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.recalculate_project_progress_v1(p_project_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_total_tasks INT;
    v_avg_progress INT;
BEGIN
    SELECT COUNT(*), COALESCE(ROUND(AVG(progress_percent)), 0)
    INTO v_total_tasks, v_avg_progress
    FROM public.project_tasks
    WHERE project_id = p_project_id AND status NOT IN ('cancelled', 'archived');

    -- If no eligible tasks, we fallback to 0 or manual. The prompt prefers: "no eligible tasks -> 0"
    IF v_total_tasks > 0 THEN
        UPDATE public.projects
        SET progress_percent = v_avg_progress
        WHERE id = p_project_id;
    ELSE
        UPDATE public.projects
        SET progress_percent = 0
        WHERE id = p_project_id;
    END IF;
END;
$$;

-- Triggers to auto-recalculate progress
CREATE OR REPLACE FUNCTION public.trigger_recalculate_task_progress()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        PERFORM public.recalculate_task_progress_v1(OLD.task_id);
        RETURN OLD;
    ELSE
        PERFORM public.recalculate_task_progress_v1(NEW.task_id);
        RETURN NEW;
    END IF;
END;
$$;

CREATE TRIGGER on_subtask_change_recalc_task_progress
    AFTER INSERT OR UPDATE OR DELETE ON public.project_subtasks
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_recalculate_task_progress();

CREATE OR REPLACE FUNCTION public.trigger_recalculate_project_progress()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        PERFORM public.recalculate_project_progress_v1(OLD.project_id);
        RETURN OLD;
    ELSE
        PERFORM public.recalculate_project_progress_v1(NEW.project_id);
        RETURN NEW;
    END IF;
END;
$$;

CREATE TRIGGER on_task_change_recalc_project_progress
    AFTER INSERT OR UPDATE OR DELETE ON public.project_tasks
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_recalculate_project_progress();


-- 4. RLS Setup
ALTER TABLE public.project_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.project_subtasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_assignees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subtask_assignees ENABLE ROW LEVEL SECURITY;

-- project_tasks policies
CREATE POLICY "Admins can manage tasks" ON public.project_tasks
    FOR ALL
    TO authenticated
    USING (public.is_active_admin())
    WITH CHECK (public.is_active_admin());

CREATE POLICY "Members can view tasks" ON public.project_tasks
    FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.project_members
            WHERE project_id = project_tasks.project_id
            AND user_id = auth.uid()
        )
    );

-- project_subtasks policies
CREATE POLICY "Admins can manage subtasks" ON public.project_subtasks
    FOR ALL
    TO authenticated
    USING (public.is_active_admin())
    WITH CHECK (public.is_active_admin());

CREATE POLICY "Members can view subtasks" ON public.project_subtasks
    FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.project_tasks t
            JOIN public.project_members pm ON t.project_id = pm.project_id
            WHERE t.id = project_subtasks.task_id
            AND pm.user_id = auth.uid()
        )
    );

-- task_assignees policies
CREATE POLICY "Admins can manage task_assignees" ON public.task_assignees
    FOR ALL
    TO authenticated
    USING (public.is_active_admin())
    WITH CHECK (public.is_active_admin());

CREATE POLICY "Members can view task_assignees" ON public.task_assignees
    FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.project_tasks t
            JOIN public.project_members pm ON t.project_id = pm.project_id
            WHERE t.id = task_assignees.task_id
            AND pm.user_id = auth.uid()
        )
    );

-- subtask_assignees policies
CREATE POLICY "Admins can manage subtask_assignees" ON public.subtask_assignees
    FOR ALL
    TO authenticated
    USING (public.is_active_admin())
    WITH CHECK (public.is_active_admin());

CREATE POLICY "Members can view subtask_assignees" ON public.subtask_assignees
    FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM public.project_subtasks st
            JOIN public.project_tasks t ON st.task_id = t.id
            JOIN public.project_members pm ON t.project_id = pm.project_id
            WHERE st.id = subtask_assignees.subtask_id
            AND pm.user_id = auth.uid()
        )
    );

-- 5. RPCs for transactional creation & reordering
CREATE OR REPLACE FUNCTION public.create_task_with_assignees_v1(
    p_project_id UUID,
    p_title TEXT,
    p_description TEXT,
    p_status TEXT,
    p_priority TEXT,
    p_start_date DATE,
    p_due_date DATE,
    p_estimated_minutes INTEGER,
    p_progress_percent INTEGER,
    p_sort_order INTEGER,
    p_assignee_ids JSONB -- array of uuids
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
    v_task_id UUID;
    v_user_id UUID;
    v_creator UUID;
BEGIN
    v_creator := auth.uid();
    IF v_creator IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
    IF NOT public.is_active_admin() THEN RAISE EXCEPTION 'Permission denied'; END IF;

    -- Insert task
    INSERT INTO public.project_tasks (
        project_id, title, description, status, priority, 
        start_date, due_date, estimated_minutes, progress_percent, 
        sort_order, created_by
    ) VALUES (
        p_project_id, p_title, p_description, p_status, p_priority, 
        p_start_date, p_due_date, p_estimated_minutes, p_progress_percent, 
        p_sort_order, v_creator
    ) RETURNING id INTO v_task_id;

    -- Insert assignees
    IF p_assignee_ids IS NOT NULL AND jsonb_array_length(p_assignee_ids) > 0 THEN
        FOR v_user_id IN SELECT jsonb_array_elements_text(p_assignee_ids)::UUID
        LOOP
            INSERT INTO public.task_assignees (task_id, user_id, assigned_by)
            VALUES (v_task_id, v_user_id, v_creator);
        END LOOP;
    END IF;

    RETURN v_task_id;
END;
$$;

REVOKE ALL ON FUNCTION public.create_task_with_assignees_v1 FROM public;
REVOKE ALL ON FUNCTION public.create_task_with_assignees_v1 FROM anon;
GRANT EXECUTE ON FUNCTION public.create_task_with_assignees_v1 TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_task_with_assignees_v1 TO service_role;

CREATE OR REPLACE FUNCTION public.reorder_project_tasks_v1(
    p_project_id UUID,
    p_ordered_task_ids JSONB -- array of uuids in order
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
    v_task_id UUID;
    v_idx INT;
BEGIN
    IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
    IF NOT public.is_active_admin() THEN RAISE EXCEPTION 'Permission denied'; END IF;

    IF p_ordered_task_ids IS NOT NULL THEN
        v_idx := 0;
        FOR v_task_id IN SELECT jsonb_array_elements_text(p_ordered_task_ids)::UUID
        LOOP
            -- Validate task belongs to project
            UPDATE public.project_tasks
            SET sort_order = v_idx, updated_at = now()
            WHERE id = v_task_id AND project_id = p_project_id;
            
            v_idx := v_idx + 1;
        END LOOP;
    END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.reorder_project_tasks_v1 FROM public;
REVOKE ALL ON FUNCTION public.reorder_project_tasks_v1 FROM anon;
GRANT EXECUTE ON FUNCTION public.reorder_project_tasks_v1 TO authenticated;
GRANT EXECUTE ON FUNCTION public.reorder_project_tasks_v1 TO service_role;
